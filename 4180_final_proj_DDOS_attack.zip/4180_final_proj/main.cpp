#include "mbed.h"
#include "EthernetInterface.h"


//BusOut leds(LED1,LED2,LED3,LED4); //LEDs are controlled by web page text data
// Network interface
EthernetInterface net;

// Socket demo
int main()
{
    // Show MAC in case it is needed to enable DHCP on a secure network
    char mac[6];
    mbed_mac_address(mac);
    printf("\r\rmbed's MAC address is %02x:%02x:%02x:%02x:%02x:%02x\n\r", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    // Bring up the ethernet interface
    printf("Waiting for IP address from DHCP Server\n\r");
    wait(1.0);
    net.connect();
    printf("\n\rEthernet socket example\n\r");

    // Show the network address
    const char *ip = net.get_ip_address();
    printf("IP address is: %s\n\r", ip ? ip : "Timeout - No IP obtained");
  
    // Send a simple http request
    char sbuffer[] = "POST / HTTP/1.1\r\nHost: 192.168.137.34\n\r\n";
    int scount1 = 0;
    int scount2 = 0;

    while (scount1 != -3004) { 
        TCPSocket socket;
        //socket.set_blocking(false);
        socket.open(&net);
        socket.connect("192.168.137.34", 80);
        scount1 = socket.send(sbuffer, 1072);
        TCPSocket socket2;
        socket2.open(&net);
        socket2.connect("192.168.137.34", 50000);
        scount2 = socket2.send(sbuffer, 1072);
        printf("sent1 scount1 = %d\n\r", scount1);
        printf("sent2 scount2 = %d\n\r", scount2);
        //int rcount = socket.recv(rbuffer, sizeof rbuffer);
        //printf("recv rcount = %d\n\r", rcount);
    }
}