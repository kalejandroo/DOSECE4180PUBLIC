#include "mbed.h"
#include <iostream>
#include <fstream>
#include <string>
 
 
Serial pc(USBTX, USBRX);
Serial esp(p28, p27); // tx, rx
DigitalOut reset(p26);
DigitalOut led1(LED1);
DigitalOut led4(LED4);
Timer t;
 
int  count,ended,timeout;
char buf[2024];
char snd[1024];
 
char ssid[32] = "4180 Project";     // enter WiFi router ssid inside the quotes
char pwd [32] = "12345678"; // enter WiFi router password inside the quotes

using namespace std;
 
void SendCMD(),getreply(),ESPconfig(),ESPsetbaudrate();
 void dev_recv()
{
    led1 = !led1;
    while(esp.readable()) {
        pc.putc(esp.getc());
    }
}
 
void pc_recv()
{
    led4 = !led4;
    while(pc.readable()) {
        esp.putc(pc.getc());
    }
}
 
 
int main()
{
    reset=0; //hardware reset for 8266
    pc.baud(9600);  // set what you want here depending on your terminal program speed
    wait(0.5);
    reset=1;
    timeout=2;
    getreply();
 
    esp.baud(9600);   // change this to the new ESP8266 baudrate if it is changed at any time.
    
    ESPconfig();        //******************  include Config to set the ESP8266 configuration  ***********************
 
    pc.attach(&pc_recv, Serial::RxIrq);
    esp.attach(&dev_recv, Serial::RxIrq);
    
    // continuosly get AP list and IP
    while(1) {
        sleep();
    }
 
}
 
// Sets new ESP8266 baurate, change the esp.baud(xxxxx) to match your new setting once this has been executed
void ESPsetbaudrate()
{
    strcpy(snd, "AT+CIOBAUD=115200\r\n");   // change the numeric value to the required baudrate
    SendCMD();
}
 
//  +++++++++++++++++++++++++++++++++ This is for ESP8266 config only, run this once to set up the ESP8266 +++++++++++++++
void ESPconfig()
{    
    pc.printf("\n---------- Setting up u[sic]ga fake webpage (http) ----------\r\n");
    strcpy(snd, "srv=net.createServer(net.TCP)\r\n");
    SendCMD();
    wait(1);
    
    strcpy(snd, "srv:listen(80,function(conn)\r\n");
    SendCMD();
    wait(1);
    
    strcpy(snd, "conn:on(\"receive\",function(conn,payload)\r\n");
    SendCMD();
    wait(1);
    
    strcpy(snd, "print(payload)\r\n");
    SendCMD();
    wait(1);
    
    strcpy(snd, "conn:send(\"<!DOCTYPE html>\")\r\n");
    SendCMD();
    wait(1);
    
    strcpy(snd, "conn:send(\"<html>\")\r\n");
    SendCMD();
    wait(1);
    
    strcpy(snd, "conn:send(\"<h1> University of Georgia</h1>\")\r\n");
    SendCMD();
    wait(1);
    
    strcpy(snd, "conn:send(\"<h2> Undergraduate Admissions</h2>\")\r\n");
    SendCMD();
    wait(1);


    strcpy(snd, "conn:send(\"<h3> First Year Admission Criteria</h3>\")\r\n");
    SendCMD();
    wait(1);
    
    strcpy(snd, "conn:send(\"<ul> <li>High School Grades</li> <li>Standardized Test (SAT or ACT)</li> <li>Secondary School Report (Minimum of Two)</li> <li>Letters of Recommendation</li></ul>\")\r\n");
    SendCMD();
    wait(1);
     
    strcpy(snd, "conn:send(\"</html>\")\r\n");
    SendCMD();
    wait(1);
        
    strcpy(snd, "end)\r\n");
    SendCMD();
    wait(1);
        
    strcpy(snd, "conn:on(\"sent\",function(conn) conn:close() end)\r\n");
    SendCMD();
    wait(1);
    
    strcpy(snd, "end)\r\n");
    SendCMD();
    wait(1);
    timeout=17;
    getreply();
    pc.printf(buf);
    pc.printf("\r\nDONE");
        
    pc.printf("\n---------- Get IP address for webpage----------\r\n");
    strcpy(snd, "print(wifi.sta.getip())\r\n");
    SendCMD();
    timeout=3;
    getreply();
    pc.printf(buf);
 
}
 
void SendCMD()
{
    esp.printf("%s", snd);
}
 
void getreply()
{
    memset(buf, '\0', sizeof(buf));
    t.start();
    ended=0;
    count=0;
    while(!ended) {
        if(esp.readable()) {
            buf[count] = esp.getc();
            count++;
        }
        if(t.read() > timeout) {
            ended = 1;
            t.stop();
            t.reset();
        }
    }
}
 
    